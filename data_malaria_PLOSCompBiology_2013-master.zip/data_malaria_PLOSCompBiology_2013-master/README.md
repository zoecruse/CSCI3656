# data_malaria_PLOSCompBiology_2013

This is a data repository for the processed sequence files, network adjacency matrices, and associated sequence metadata for the paper:

D. B. Larremore, A. Clauset, C. O. Buckee, A network approach to analyzing highly re- combinant malaria parasite genes, PLoS Comput Biol 9, e1003268 (2013).

## Interactive version of this dataset
http://danlarremore.com/var/

## Citation infomation

If you use this dataset, please refer the reader to the paper above via footnote or citation. Thanks!
